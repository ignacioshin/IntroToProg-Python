'''
------------------------------------------------------------------------------
Developer:  Iggy Shin
Desc: Assignment05

1.	Create a text file called Todo.txt using the following data:

Clean House,low
Pay Bills,high

2.	When the program starts, load each row of data from the ToDo.txt text file into a
Python dictionary.

Tip: You can use a for loop to read a single line of text from the file and then place the
data into a new dictionary object.

3.	After you get a row of data stored in a Python dictionary, add the new “row” into a
Python List object (now the data will be managed as a table or two-dimensional array).

4.	Display the contents of the List to the user.

5.	Allow the user to Add or Remove tasks from the list using numbered choices.
Something like this would work:

    print ("Choose 1 to Add task")
    print ("Choose 2 to Remove task")
    print ("Choose 3 to Save all tasks to the Todo.txt file and exit!")

6.	Save the data from the table into the Todo.txt file when the program exits.
------------------------------------------------------------------------------
'''

#import the sys module
import sys

#Load the data from Todo.txt file
objFile = open("C:\\_PythonClass\\Assignment05\\Todo.txt", "r")

#Define the list table
lsttable = []
#Define the Dictionary
dictrowFile = {}


# Split the data into two key values
try:
    for row in objFile:
        dictrowFile = {"Task":(row.split(',')[0]).strip(),
                   "Priority":(row.split(',')[1].strip())}
        lsttable.append(dictrowFile)

except:
    print("Please enter inital Values on the Todo.txt file")

#Close the file
objFile.close()

#Start the line number at 0
line = int(0)

print("These are the tasks and priorities in the list")

#Print the table along with the line number
for (row) in lsttable:
    line +=1
    print ("Task Number:",line, row)

#Start a loop to ask the user's input
while (True):
    strUserinput = input("Choose 1 to Add task\n" "Choose 2 to Remove task \n"
    "Choose 3 to Save all tasks to the Todo.txt file and exit! " "\n" "Enter 1,2,or 3: ")

#If user's choice is 1, then append the data to lsttable
    if strUserinput == "1":
        strtask = input ("Please enter a task: ")
        strpriority = input ("Please enter the priority for " + strtask + ": ")
        dictrowUI = {"Task":strtask, "Priority":strpriority}
        lsttable.append(dictrowUI)
        line = int(0)
        for row in lsttable:
            line += 1
            print ("Task Number:",line,row)

#If User's choice is 2 then ask which task line number they want to remove.  Pop this index.
    if strUserinput == "2":
        strRemoveTask = int(input ("Which Task number do you want to remove? "))
        lsttable.pop(strRemoveTask-1)

        line = int(0)
        print("These tasks are left")
        for row in lsttable:
            line +=1
            print (line,row)

# If user's input is 3, then quit the loop
    if strUserinput == "3":break

# Save the file to Todo.txt and remove unnecessary Brackets

print("Tasks has been saved to Todo.txt file")
objFile = open("C:\\_PythonClass\\Assignment05\\Todo.txt", "w")

for row in lsttable:
    newlst = str(row).strip().replace("'Task'","").replace("'Priority'", "")\
        .replace("{:","").replace("}","").replace(":","")\
        .replace("'","")
    objFile.write(str(newlst) + "\n")

objFile.close()